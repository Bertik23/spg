from engine import *
import random
import json

import os
import sys

with open("dungeonText.json", encoding="utf-8") as f:
    graphJson = json.load(f)

for i in graphJson:
    graph.addRoom(**graphJson[i])

# for i in graph.rooms:
#     print(i)

player = Player("A")
#player = Player(input(whiteText("Jak se jmenuješ?\n")))


# for i in graph.rooms:
#     print(i)
#graph.visualize()

playGame(player)